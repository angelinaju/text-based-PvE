# Entity Clash: A C++ Text-Based Player vs Entity game for COSC202

To compile: 
g++ -c pve.cpp -o pve.o
g++ -c main.cpp -o main.o
g++ main.o pve.o -o game
./game

To play, just follow the instructions and input the number that you want to use.